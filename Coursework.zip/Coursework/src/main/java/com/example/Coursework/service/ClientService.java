package com.example.Coursework.service;

import com.example.Coursework.entity.Client;
import com.example.Coursework.repository.ClientRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClientService {
    @Autowired
    private ClientRepo clientRepo;

    public Client addClient(Client client) {
        return clientRepo.save(client);
    }

    public Client getClient(Long id) {
        Client client = clientRepo.findById(id).get();
        return client;
    }

    public Long deleteClient(Long id) {
        clientRepo.deleteById(id);
        return id;
    }

    public Client editClient(Long id, Client client) {
        Client client1 = clientRepo.findById(id).get();
        client1.setName(client.getName());
        client1.setNumber(client.getNumber());
        client1.setMaster(client.getMaster());
        return clientRepo.save(client1);
    }
}

