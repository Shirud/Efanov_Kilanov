package com.example.Coursework.controller;


import com.example.Coursework.entity.Master;
import com.example.Coursework.service.MasterService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/masters")
public class MasterController {
    @Autowired
    private MasterService masterService;
    @PostMapping
    public ResponseEntity addMaster(@RequestBody Master master){
        try {
            masterService.addMaster(master);
            return ResponseEntity.ok("Мастер успешно создан");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @GetMapping
    public ResponseEntity getMaster(@RequestParam Long id) {
        try {
            return ResponseEntity.ok(masterService.getMaster(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @DeleteMapping("/{id}")
    public  ResponseEntity deleteMaster(@PathVariable Long id)   {
        try {
            return ResponseEntity.ok(masterService.deleteMaster(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @PatchMapping("/{id}")
    public ResponseEntity editMaster(@RequestBody Master master, @PathVariable Long id){
        try {
            masterService.editMaster(id, master);
            return ResponseEntity.ok("Мастер был успешно изменен!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }
}


