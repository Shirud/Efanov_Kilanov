package com.example.Coursework.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
public class Master {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Long id;
    private String area;
    private String name;
    private String Client;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "masterN")
    private List<Client> privyazka;

    @ManyToOne
    @JoinColumn(name = "Area_id")
    private Area areaN;
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClient() {
        return Client;
    }

    public void setClient(String client) {
        Client = client;
    }

    public Master() {

    }
}
