package com.example.Coursework.repository;

import com.example.Coursework.entity.Master;
import org.springframework.data.repository.CrudRepository;
public interface MasterRepo extends CrudRepository <Master, Long> {
}
