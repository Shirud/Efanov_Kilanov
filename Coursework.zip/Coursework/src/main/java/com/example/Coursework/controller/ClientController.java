package com.example.Coursework.controller;

import com.example.Coursework.entity.Client;
import com.example.Coursework.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/clients")
public class ClientController {
    @Autowired
    private ClientService clientService;
    @PostMapping
    public ResponseEntity addClient(@RequestBody Client client){
        try {
            clientService.addClient(client);
            return ResponseEntity.ok("Клиент успешно создан");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @GetMapping
    public ResponseEntity getClient(@RequestParam Long id) {
        try {
            return ResponseEntity.ok(clientService.getClient(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @DeleteMapping("/{id}")
    public  ResponseEntity deleteClient(@PathVariable Long id)   {
        try {
            return ResponseEntity.ok(clientService.deleteClient(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @PatchMapping("/{id}")
    public ResponseEntity editClient(@RequestBody Client client, @PathVariable Long id){
        try {
            clientService.editClient(id, client);
            return ResponseEntity.ok("Клиент был успешно изменен!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }
}
