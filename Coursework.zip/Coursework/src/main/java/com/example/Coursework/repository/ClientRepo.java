package com.example.Coursework.repository;

import com.example.Coursework.entity.Client;
import org.springframework.data.repository.CrudRepository;
public interface ClientRepo extends CrudRepository <Client, Long > {
}
