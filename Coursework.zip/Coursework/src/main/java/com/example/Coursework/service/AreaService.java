package com.example.Coursework.service;

import com.example.Coursework.entity.Area;
import com.example.Coursework.repository.AreaRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AreaService {
    @Autowired
    private AreaRepo areaRepo;

    public Area addArea(Area place) {
        return areaRepo.save(place);
    }

    public Area getArea(Long id) {
        Area place = areaRepo.findById(id).get();
        return place;
    }

    public Long deleteArea(Long id) {
        areaRepo.deleteById(id);
        return id;
    }

    public Area editArea(Long id, Area place) {
        Area place1 = areaRepo.findById(id).get();
        place1.setAdress(place.getAdress());
        place1.setTime(place.getTime());
        place1.setMaster(place.getMaster());
        return areaRepo.save(place1);
    }
}
