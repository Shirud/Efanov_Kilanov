package com.example.Coursework.repository;

import com.example.Coursework.entity.Area;
import org.springframework.data.repository.CrudRepository;

public interface AreaRepo extends CrudRepository <Area, Long > {
}