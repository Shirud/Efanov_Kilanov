package com.example.Coursework.controller;

import com.example.Coursework.entity.Area;
import com.example.Coursework.service.AreaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/users")
public class AreaController {

    @Autowired
    private AreaService areaService;
    @PostMapping
    public ResponseEntity addArea(@RequestBody Area place) {
        try {
            areaService.addArea(place);
            return ResponseEntity.ok("Место успешно создано");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }
    @GetMapping
    public ResponseEntity getArea(@RequestParam Long id) {
        try {
            return ResponseEntity.ok(areaService.getArea(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }

    @DeleteMapping("/{id}")
    public  ResponseEntity deleteArea(@PathVariable Long id)   {
        try {
            return ResponseEntity.ok(areaService.deleteArea(id));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Произошла ошибка");
        }
    }

    @PatchMapping("/{id}")
    public ResponseEntity editArea(@RequestBody Area place, @PathVariable Long id){
        try {
            areaService.editArea(id, place);
            return ResponseEntity.ok("Место было успешно изменено!");
        } catch (Exception e){
            return ResponseEntity.badRequest().body("Ошибка");
        }
    }
}