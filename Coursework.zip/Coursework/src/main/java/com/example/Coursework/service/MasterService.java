package com.example.Coursework.service;
;
import com.example.Coursework.entity.Master;
import com.example.Coursework.repository.MasterRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MasterService {

        @Autowired
        private MasterRepo masterRepo;

        public Master addMaster(Master master) {
            return masterRepo.save(master);
        }

        public Master getMaster(Long id) {
            Master master = masterRepo.findById(id).get();
            return master;
        }

        public Long deleteMaster(Long id) {
            masterRepo.deleteById(id);
            return id;
        }

        public Master editMaster(Long id, Master master) {
            Master master1 = masterRepo.findById(id).get();
            master1.setArea(master.getArea());
            master1.setName(master.getName());
            master1.setClient(master.getClient());
            return masterRepo.save(master1);
        }
    }

