package com.example.Coursework.Client;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author danya
 */
public class Fe {

    public static void main(String args[]) {
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }
    
}

